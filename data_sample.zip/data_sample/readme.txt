Files of one game in the corpus (100 games in total):

webpage.htm: the webpage from which the team rosters and play-by-play information were crawled.

information.csv: play-by-play information of this game.
gt: the game timestamp.
vt(gt): the broadcast timestamps mapping into the game timestamp.
vt(gt+10s)~vt(gt+1s): the broadcast timestamps mapping into all game timestamps up to 10 seconds before the game timestamp
vt(gt-10s)~vt(gt-1s): the broadcast timestamps mapping into all game timestamps up to 10 seconds after the game timestamp
possessors: the list of players who had the ball in that play
teams: the team or teams the possessors play for
'#' means timestamps that are wrongly recognized. eg: recognize digit 5 as 3 due to their similar shapes
'?' means timestamps that fail to be recognized.

SeattleSeahawks.txt: the team roster of Seattle Seahawks.

TampaBayBuccaneers.txt: the team roster of TampaBay Buccaneers.

audio.flac: audio file of this game, not included this time due to the size limit.

transcript.json: the automatic transcription of the broadcast using Google Cloud.

broadcast.mp4: video file of this game, not included this time due to the size limit.